Compile
	make
Run
	example4.1 a b c
