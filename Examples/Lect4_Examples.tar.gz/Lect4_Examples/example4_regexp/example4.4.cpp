#include <string>
#include <vector>
#include <iostream>

#include <regex>

#include <stdlib.h>

int main(){
  std::vector<std::string> data; // container
  data.push_back("HLT_ZeroBias");
  data.push_back("HLT_Ele30_WPTight_Gsf");
  data.push_back("HLT_IsoMu20_eta2p1_LooseDeepTauPFTauHPS27_eta2p1_CrossL1");
  data.push_back("HLT_AK8PFJet40");
  data.push_back("HLT_LooseDeepTauPFTauHPS180_L2NN_eta2p1");
  data.push_back("HLT_PFMET120_PFMHT120_IDTight");
  data.push_back("HLT_DoublePNetTauhPFJet30_Loose_L2NN_eta2p3");

  //std::string re_str = "DeepTau"; // regex
  std::string re_str = "(DeepTau|PNetTauh)"; // regex
  std::regex example_re(re_str);
  std::cout << "regex search pattern " << re_str << std::endl;
  std::smatch what;
 
  std::vector<std::string>::const_iterator i; //iterator
  for(i = data.begin(); i!=data.end(); ++i){
    if (std::regex_search(*i,what,example_re)) std::cout << "string " << *i << " \x1B[32mmatches\033[0m" << std::endl; // colored output
    else std::cout << "string " << *i << " \x1B[31mdoes not match\033[0m" << std::endl;
  }
}

