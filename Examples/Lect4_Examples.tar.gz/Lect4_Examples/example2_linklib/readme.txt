Compile
	make
Run
	example4.2.job

Notes:
https://ftp.gnu.org/old-gnu/Manuals/make-3.79.1/html_chapter/make_toc.html#TOC101
$@
    The file name of the target of the rule.
$<
    The name of the first prerequisite.

